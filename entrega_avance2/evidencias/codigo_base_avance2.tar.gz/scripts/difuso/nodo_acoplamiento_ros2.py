#!/usr/bin/env python3
"""Nodo de acoplamiento difuso del AGV - Avance 2.

Modo por defecto: diagnóstico, sin movimiento.
La ejecución física requiere un supervisor de seguridad externo.
"""

import argparse
import csv
from datetime import datetime
import math
import sys
import time
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.duration import Duration
from tf2_ros import Buffer, TransformListener, TransformException
from rclpy.qos import (
    QoSProfile,
    ReliabilityPolicy,
    DurabilityPolicy,
    HistoryPolicy,
)
from geometry_msgs.msg import Twist, PoseWithCovarianceStamped

sys.path.insert(0, str(Path(__file__).resolve().parent))
from controlador_agv import crear_simulacion
from monitor_seguridad import distancia_frontal
from sensor_msgs.msg import LaserScan
from supervisor_geometrico import (
    calcular_errores,
    evaluar_preacople,
    evaluar_acople,
)


def normalizar_angulo(angulo):
    return math.atan2(math.sin(angulo), math.cos(angulo))


class NodoAcoplamiento(Node):

    def __init__(self, args):
        super().__init__("nodo_acoplamiento_difuso")

        self.objetivo_x = args.x
        self.objetivo_y = args.y
        self.objetivo_yaw = math.radians(args.yaw)

        self.distancia_deseada = args.distancia
        self.tolerancia_distancia = args.tolerancia
        self.tolerancia_angular = math.radians(args.tolerancia_angular)

        self.tiempo_estable = args.tiempo_estable
        self.tiempo_maximo = args.tiempo_maximo

        self.ejecutar = args.ejecutar

        self.simulacion = crear_simulacion()

        self.ultimo_scan = None
        self.instante_scan = None
        self.sub_scan = self.create_subscription(
            LaserScan, "/scan", self.recibir_scan, 10
        )

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.pose = None
        self.ultima_pose = None

        self.inicio = time.monotonic()
        self.inicio_estable = None
        self.finalizado = False
        self.estado_final = "EN_PROCESO"
        self.ultimo_motivo = "SIN_EVALUAR"
        self.archivo_registro = (
            Path(__file__).resolve().parents[2]
            / "datos/registros/acoplamientos.csv"
        )
        self.registro_guardado = False
        self.ultimos_errores = None

        qos_amcl = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )

        self.sub_pose = self.create_subscription(
            PoseWithCovarianceStamped,
            "/amcl_pose",
            self.recibir_pose,
            qos_amcl
        )

        self.pub_vel = self.create_publisher(
            Twist,
            "/cmd_vel",
            10
        )

        self.timer = self.create_timer(0.2, self.controlar)

        self.get_logger().info(
            f"Objetivo: ({self.objetivo_x:.3f}, "
            f"{self.objetivo_y:.3f}), "
            f"yaw={args.yaw:.2f} grados"
        )

        self.get_logger().info(
            "MODO EJECUCION" if self.ejecutar
            else "MODO DIAGNOSTICO - SIN MOVIMIENTO"
        )

    def recibir_scan(self, msg):
        self.ultimo_scan = msg
        self.instante_scan = time.monotonic()

    def comprobar_lidar(self):
        if self.ultimo_scan is None or self.instante_scan is None:
            return False, "SIN_LIDAR"

        if time.monotonic() - self.instante_scan > 1.0:
            return False, "LIDAR_DESACTUALIZADO"

        distancia = distancia_frontal(self.ultimo_scan)

        if distancia is None:
            return False, "SIN_LECTURAS_FRONTALES_VALIDAS"

        if distancia < 0.30:
            return False, f"OBSTACULO_FRONTAL_{distancia:.3f}m"

        return True, "LIDAR_APTO"

    def recibir_pose(self, msg):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation

        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        )

        self.pose = (p.x, p.y, yaw)
        self.ultima_pose = time.monotonic()

    def actualizar_pose_tf(self):
        try:
            transformacion = self.tf_buffer.lookup_transform(
                "map",
                "base_footprint",
                Time(),
                timeout=Duration(seconds=0.05),
            )

            p = transformacion.transform.translation
            q = transformacion.transform.rotation

            yaw = math.atan2(
                2.0 * (q.w * q.z + q.x * q.y),
                1.0 - 2.0 * (q.y * q.y + q.z * q.z),
            )

            self.pose = (p.x, p.y, yaw)
            self.ultima_pose = time.monotonic()
            return True

        except TransformException as exc:
            self.get_logger().warning(
                f"No se pudo consultar TF: {exc}"
            )
            return False

    def detener(self):
        if self.ejecutar:
            self.pub_vel.publish(Twist())

    def guardar_registro(self):
        if self.registro_guardado:
            return

        archivo = self.archivo_registro
        archivo.parent.mkdir(parents=True, exist_ok=True)

        errores = self.ultimos_errores or {}
        columnas = [
            "fecha_hora", "modo", "objetivo_x", "objetivo_y",
            "objetivo_yaw_deg", "resultado", "ultimo_motivo",
            "duracion_s", "error_longitudinal_m",
            "error_lateral_m", "error_angular_deg"
        ]

        fila = {
            "fecha_hora": datetime.now().astimezone().isoformat(
                timespec="seconds"
            ),
            "modo": "EJECUCION" if self.ejecutar else "DIAGNOSTICO",
            "objetivo_x": self.objetivo_x,
            "objetivo_y": self.objetivo_y,
            "objetivo_yaw_deg": math.degrees(self.objetivo_yaw),
            "resultado": self.estado_final,
            "ultimo_motivo": self.ultimo_motivo,
            "duracion_s": round(time.monotonic() - self.inicio, 3),
            "error_longitudinal_m": errores.get("longitudinal", ""),
            "error_lateral_m": errores.get("lateral", ""),
            "error_angular_deg": (
                math.degrees(errores["angular"])
                if "angular" in errores else ""
            ),
        }

        nuevo = not archivo.exists() or archivo.stat().st_size == 0

        with archivo.open("a", newline="", encoding="utf-8") as f:
            escritor = csv.DictWriter(f, fieldnames=columnas)
            if nuevo:
                escritor.writeheader()
            escritor.writerow(fila)

        self.registro_guardado = True
        self.get_logger().info(f"Registro guardado: {archivo}")

    def terminar(self, mensaje):
        self.detener()
        self.estado_final = mensaje
        self.finalizado = True
        self.guardar_registro()
        self.get_logger().info(mensaje)

    def controlar(self):
        if self.finalizado:
            return

        ahora = time.monotonic()

        # La pose de control procede de TF2.
        # No reutilizar una pose anterior si TF no está disponible.
        if not self.actualizar_pose_tf():
            self.inicio_estable = None
            self.detener()
            return

        if ahora - self.inicio > self.tiempo_maximo:
            self.terminar("TIEMPO MAXIMO ALCANZADO")
            return

        if self.pose is None:
            self.get_logger().info("Esperando AMCL...")
            return

        if ahora - self.ultima_pose > 1.0:
            self.inicio_estable = None
            self.detener()
            self.get_logger().warning("AMCL desactualizado")
            return

        x, y, yaw = self.pose

        seguro, motivo_seguridad = self.comprobar_lidar()
        if not seguro:
            self.inicio_estable = None
            self.detener()
            self.get_logger().warning(
                f"ACOPLAMIENTO BLOQUEADO: {motivo_seguridad}"
            )
            return

        errores = calcular_errores(
            x, y, yaw,
            self.objetivo_x,
            self.objetivo_y,
            self.objetivo_yaw,
        )

        self.ultimos_errores = errores
        apto, motivo = evaluar_preacople(errores)

        if not apto:
            self.ultimo_motivo = motivo
            self.inicio_estable = None
            self.detener()
            self.get_logger().warning(
                f"PREACOPLE NO APTO: {motivo} | "
                f"lateral={errores['lateral']:.3f} m | "
                f"angular={math.degrees(errores['angular']):.2f} deg"
            )
            return

        dx = self.objetivo_x - x
        dy = self.objetivo_y - y

        distancia = math.hypot(dx, dy)

        error_distancia = distancia - self.distancia_deseada

        angulo_hacia_objetivo = math.atan2(dy, dx)

        error_direccion = normalizar_angulo(
            angulo_hacia_objetivo - yaw
        )

        error_orientacion_final = normalizar_angulo(
            self.objetivo_yaw - yaw
        )

        dentro_distancia = (
            abs(error_distancia) <= self.tolerancia_distancia
        )

        dentro_angulo = (
            abs(error_orientacion_final)
            <= self.tolerancia_angular
        )

        if dentro_distancia and dentro_angulo:
            self.detener()

            if self.inicio_estable is None:
                self.inicio_estable = ahora

            if ahora - self.inicio_estable >= self.tiempo_estable:
                self.terminar("ACOPLAMIENTO COMPLETADO")
                return

            self.get_logger().info(
                "Dentro de tolerancias; estabilizando..."
            )
            return

        self.inicio_estable = None

        # Ajuste final longitudinal.
        # Solo se alcanza si el supervisor geométrico
        # ha autorizado el preacople.
        if distancia <= 0.05:
            ed = max(
                -0.05,
                min(0.45, errores["longitudinal"])
            )

            et = max(
                -20.0,
                min(
                    20.0,
                    math.degrees(error_orientacion_final)
                )
            )

            try:
                self.simulacion.input["ed"] = ed
                self.simulacion.input["et"] = et
                self.simulacion.compute()

                v = float(self.simulacion.output["v"])

            except Exception as exc:
                self.get_logger().error(
                    f"Error difuso: {exc}"
                )
                self.terminar("FALLO DEL CONTROLADOR")
                return

            # Limitar la velocidad en el ajuste final.
            v = max(-0.035, min(0.035, v))

            # Orientación final corregida por separado.
            w = max(
                -0.2,
                min(0.2, 1.5 * error_orientacion_final)
            )

        else:
            error_grados = math.degrees(error_direccion)

            # Evitar avance con desalineación elevada.
            if abs(error_grados) > 20.0:
                v = 0.0
                w = max(
                    -0.6,
                    min(0.6, 1.5 * error_direccion)
                )
            else:
                ed = max(
                    -0.05,
                    min(0.45, error_distancia)
                )

                et = max(
                    -20.0,
                    min(20.0, error_grados)
                )

                try:
                    self.simulacion.input["ed"] = ed
                    self.simulacion.input["et"] = et
                    self.simulacion.compute()

                    v = float(self.simulacion.output["v"])
                    w = float(self.simulacion.output["w"])

                except Exception as exc:
                    self.get_logger().error(
                        f"Error difuso: {exc}"
                    )
                    self.terminar("FALLO DEL CONTROLADOR")
                    return

        if not math.isfinite(v) or not math.isfinite(w):
            self.terminar("SALIDA NO FINITA")
            return

        comando = Twist()
        comando.linear.x = v
        comando.angular.z = w

        if self.ejecutar:
            self.pub_vel.publish(comando)

        self.get_logger().info(
            f"Dist={distancia:.3f} m | "
            f"ed={error_distancia:.3f} m | "
            f"e_dir={math.degrees(error_direccion):.2f} deg | "
            f"e_yaw={math.degrees(error_orientacion_final):.2f} deg | "
            f"v={v:.3f} m/s | "
            f"w={w:.3f} rad/s"
        )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--x", type=float, required=True)
    parser.add_argument("--y", type=float, required=True)

    parser.add_argument("--yaw", type=float, default=0.0)

    parser.add_argument(
        "--distancia", type=float, default=0.0
    )

    parser.add_argument(
        "--tolerancia", type=float, default=0.01
    )

    parser.add_argument(
        "--tolerancia-angular", type=float, default=5.0
    )

    parser.add_argument(
        "--tiempo-estable", type=float, default=1.0
    )

    parser.add_argument(
        "--tiempo-maximo", type=float, default=60.0
    )

    parser.add_argument(
        "--ejecutar", action="store_true"
    )

    args = parser.parse_args()

    if (
        args.distancia < 0
        or args.tolerancia <= 0
        or not 0 < args.tolerancia_angular <= 180
        or args.tiempo_estable <= 0
        or args.tiempo_maximo <= 0
    ):
        parser.error("Parametros de tolerancia o tiempo invalidos")

    # Bloqueo preventivo de movimiento hasta integrar
    # supervisor, comprobación de obstáculos y exclusividad /cmd_vel.
    if args.ejecutar:
        parser.error(
            "Ejecucion bloqueada: falta integrar el supervisor "
            "y las protecciones de seguridad."
        )

    rclpy.init()
    nodo = NodoAcoplamiento(args)

    try:
        rclpy.spin(nodo)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        nodo.detener()
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
